﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HobbyKlub
{
    public partial class MemberForm : Form
    {
        public MemberForm(Member member)
        {
            this.member = member;
            InitializeComponent();
        }

        Member member;

        private void okButton_Click(object sender, EventArgs e)
        {
            using (var db = new HobbyKlubEntities())
            {
                if (member != null)
                {
                    db.Members.Attach(member);
                }
                else
                {
                    member = new Member();
                    db.Members.AddObject(member);
                }

                member.Address = address.Text;
                member.Mail = mail.Text;
                member.Mobile = mobile.Text;
                member.Name = name.Text;

                db.SaveChanges();

                int xxx = 0;
            }

            DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void MemberForm_Load(object sender, EventArgs e)
        {
            if (member != null)
            {
                this.name.Text = member.Name;
                this.mobile.Text = member.Mobile;
                this.mail.Text = member.Mail;
                this.address.Text = member.Address;
            }
        }
    }
}
